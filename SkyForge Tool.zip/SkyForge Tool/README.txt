SkyForge Tool - Version 2.1.0 Beta
========================================

Willkommen zum SkyForge Tool! Dieses Tool bietet eine einfache Benutzeroberfläche,
um verschiedene Skripte anzuzeigen und deinen Discord-Server zu öffnen.

Hinweis: Dies ist keine Vollversion. Einige Funktionen könnten fehlen oder nicht
vollständig verfügbar sein.

Funktionen:
-----------
1. **Slap Battles Scripts anzeigen**:
   - Zeigt ein Admin Glove Script für das Spiel "Slap Battles" an.
   - Einfach das Skript kopieren und in deinen Executor einfügen.

2. **Bloxfruit Script anzeigen**:
   - Zeigt ein Script für das Spiel "Bloxfruit" an.
   - Das Skript hat den Key "vortex42244". Kopiere es und füge es in deinen Executor ein.

3. **Discord Server öffnen**:
   - Öffnet den SkyForgeX37 Discord Server im Standard-Browser.

4. **Beenden**:
   - Beendet das SkyForge Tool.

Bitte beachte, dass das Tool derzeit als Beta-Version vorliegt und sich noch in der Entwicklung befindet.

Erstellt von: **SkyForgeX37**

Viel Spaß beim Verwenden!
